document.addEventListener('DOMContentLoaded', function () {
    const enquiryForm = document.querySelector('form');

    if (!enquiryForm) return;

    enquiryForm.addEventListener('submit', function (event) {
        const name = document.getElementById('name')?.value.trim();
        const email = document.getElementById('email')?.value.trim();
        const phone = document.getElementById('phone')?.value.trim();
        const message = document.getElementById('message')?.value.trim();

        if (!name || !email || !phone || !message) {
            event.preventDefault();
            alert('Please fill in all required fields before submitting your enquiry.');
            return;
        }

        alert('Thank you! Your enquiry has been sent successfully.');
    });
});
