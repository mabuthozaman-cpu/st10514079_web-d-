# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added
- Created the website structure with multiple pages for home, about, services, and contact.
- Added a contact form with required fields and validation.
- Integrated FormSubmit for email-based enquiry handling.
- Added a thank-you page after successful form submission.
- Added responsive styling for mobile and tablet layouts.
- Added SEO meta tags to improve discoverability and social sharing.
- Added project documentation in `README.md`.

### Updated
- Improved the site branding and content for Mqadi Travels Car Hire.
- Refined page navigation and overall layout consistency.
- Standardized the footer messaging and copyright year script.

### Fixed
- Corrected duplicate HTML structure issues on some pages.
- Improved form validation behavior for required enquiry fields.
- Updated image path references to better match the current project folder structure.

## [1.0.0] - 2026-10-26

### Added
- Initial static website release for Mqadi Travels Car Hire.
- Home, About, Services, and Contact pages created.
- Basic styling and layout implementation.
- JavaScript support for footer year updates and form messaging.
