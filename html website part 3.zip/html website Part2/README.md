# Mqadi Travels Car Hire Website

A modern static website for a South African car hire company offering affordable and reliable vehicle rental services across KwaZulu-Natal and surrounding areas.

## Overview
This project provides a complete front-end website for Mqadi Travels Car Hire, including:
- a welcoming home page
- company profile and mission
- fleet and service overview
- contact form and enquiry submission
- responsive design for desktop and mobile devices

## Project Structure

- `index.html` – home page
- `about.html` – company information and values
- `services.html` – rental fleet and additional service offerings
- `contact.html` – enquiry form and business contact details
- `thank-you.html` – confirmation page after successful submission
- `style.css` – website styling and responsive layout
- `script.js` – general JavaScript enhancements
- `enquiry.js` – form validation for the enquiry form
- `CHANGELOG.md` – project updates and version history
- `README.md` – project documentation

## Changelog
See [`CHANGELOG.md`](CHANGELOG.md) for the latest project updates and version history.

## Technologies Used
- HTML5
- CSS3
- JavaScript
- FormSubmit for email-based form handling

## Features
- Responsive navigation and layout
- Vehicle catalog with pricing information
- Customer enquiry form with validation
- Business contact details and location map
- Professional CTA sections and branded design

## Local Setup
1. Download or clone the project files to your computer.
2. Open the folder in your preferred code editor.
3. Launch `index.html` in a browser to view the site locally.

## SEO and Search Indexing
- `robots.txt` controls which pages search engines can crawl.
- `sitemap.xml` lists the key pages for indexing.
- This project is configured for the live domain: `https://www.mqaditravels.co.za`.

## Deployment
To make the enquiry form work properly, the website should be hosted online. The form is configured to submit to:

`bookings@mqaditravels.co.za`

using FormSubmit.

## Notes
- The site is static and does not require a backend server.
- Contact form submissions will work when published online.
- Image paths should remain relative to the project folder to ensure assets display correctly.

## Contact
For business enquiries, use the contact details listed on the website or the email below:

`bookings@mqaditravels.co.za`
