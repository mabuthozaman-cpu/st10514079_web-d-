// Mqadi Travels Car Hire - JavaScript

document.addEventListener('DOMContentLoaded', function () {
    // Update footer year
    const footerText = document.querySelector('footer p');
    if (footerText) {
        const year = new Date().getFullYear();
        footerText.textContent = `© ${year} Mqadi Travels Car Hire. Drive Safe. Drive With Us.`;
    }

    // Highlight active nav item based on current page
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('nav a');

    navLinks.forEach(function (link) {
        const linkPage = link.getAttribute('href');
        if (linkPage === currentPage) {
            link.classList.add('active');
        }
    });

    // Form validation and custom success/error messages
    const forms = document.querySelectorAll('form');

    forms.forEach(function (form) {
        let messageBox = form.querySelector('.form-message');

        if (!messageBox) {
            messageBox = document.createElement('div');
            messageBox.className = 'form-message';
            form.appendChild(messageBox);
        }

        form.addEventListener('submit', function (event) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            const nameField = form.querySelector('input[name="name"]');
            const emailField = form.querySelector('input[type="email"]');
            const phoneField = form.querySelector('input[type="tel"]');
            const dateField = form.querySelector('input[name="dates"]');
            const messageField = form.querySelector('textarea[name="message"]');

            requiredFields.forEach(function (field) {
                if (!field.value.trim()) {
                    isValid = false;
                }
            });

            if (nameField && nameField.value.trim().length < 2) {
                isValid = false;
            }

            if (emailField) {
                const emailValue = emailField.value.trim();
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailValue)) {
                    isValid = false;
                }
            }

            if (phoneField) {
                const phoneValue = phoneField.value.trim();
                const phonePattern = /^\+?[0-9\s()-]{7,20}$/;
                if (!phonePattern.test(phoneValue)) {
                    isValid = false;
                }
            }

            if (dateField && dateField.value.trim()) {
                const dateValue = dateField.value.trim();
                const datePattern = /\d/;
                if (!datePattern.test(dateValue) || dateValue.length < 5) {
                    isValid = false;
                }
            }

            if (messageField && messageField.value.trim().length < 10) {
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault();

                if (nameField && nameField.value.trim() && nameField.value.trim().length < 2) {
                    messageBox.textContent = 'Please enter a valid full name.';
                } else if (phoneField && phoneField.value.trim() && !/^\+?[0-9\s()-]{7,20}$/.test(phoneField.value.trim())) {
                    messageBox.textContent = 'Please enter a valid phone number.';
                } else if (emailField && emailField.value.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailField.value.trim())) {
                    messageBox.textContent = 'Please enter a valid email address.';
                } else if (dateField && dateField.value.trim() && (!/\d/.test(dateField.value.trim()) || dateField.value.trim().length < 5)) {
                    messageBox.textContent = 'Please enter a valid rental date, for example 20 Aug - 25 Aug 2026.';
                } else if (messageField && messageField.value.trim().length < 10) {
                    messageBox.textContent = 'Please enter a longer message with at least 10 characters.';
                } else {
                    messageBox.textContent = 'Please complete all required fields before submitting.';
                }

                messageBox.className = 'form-message error';
                return;
            }

            messageBox.textContent = 'Thank you! Your enquiry has been sent successfully.';
            messageBox.className = 'form-message success';

            const shouldRedirect = form.action.includes('formsubmit.co') || form.action.endsWith('thank-you.html');
            if (shouldRedirect) {
                setTimeout(function () {
                    window.location.href = 'thank-you.html';
                }, 700);
            }
        });
    });
});
